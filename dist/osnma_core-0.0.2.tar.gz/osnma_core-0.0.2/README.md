# osnma_core
A Python module to help implementing Galileo OSNMA
